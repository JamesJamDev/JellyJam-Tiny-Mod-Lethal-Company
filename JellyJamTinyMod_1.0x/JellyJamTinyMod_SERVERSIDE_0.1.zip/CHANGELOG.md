Pre Release (0.1):
- Changed Player size to 20%
- Adjusted Jump, Speed, and Grab Distance values (for those who have the mod)
- IS SERVER WIDE IF YOU ARE THE HOST, but they wont get the adjusted jump height and speed.
- You may run into issues as this is a very early version